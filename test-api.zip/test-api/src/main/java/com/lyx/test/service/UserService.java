package com.lyx.test.service;

import com.lyx.test.po.User;

public interface UserService {
    User getUserById(int id); //按id查找user

    void saveUser(User user); //将user保存(存在则更新)
}
